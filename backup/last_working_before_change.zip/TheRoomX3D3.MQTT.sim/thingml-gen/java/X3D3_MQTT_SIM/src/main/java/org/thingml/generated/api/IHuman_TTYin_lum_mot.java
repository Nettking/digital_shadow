package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IHuman_TTYin_lum_mot{
void add_lightsensor_via_TTYin_lum_mot(int LuminanceMsg_add_lightsensor_id_var);
void add_motionsensor_via_TTYin_lum_mot(int MotionMsg_add_motionsensor_id_var);
}