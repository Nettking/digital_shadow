package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IPIM_guard_human{
void timer_timeout_via_guard_human();
}