package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IPIM_request_actuatorClient{
void add_device_from_request_actuator(int DeviceGeneral_add_device_did_var);
void SwitchOn_from_request_actuator(int OnOffMsg_SwitchOn_did_var);
void SwitchOff_from_request_actuator(int OnOffMsg_SwitchOff_did_var);
}