package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IEnergySaving_request_luminance_sensorClient{
void add_lightsensor_from_request_luminance_sensor(int LuminanceMsg_add_lightsensor_id_var);
}