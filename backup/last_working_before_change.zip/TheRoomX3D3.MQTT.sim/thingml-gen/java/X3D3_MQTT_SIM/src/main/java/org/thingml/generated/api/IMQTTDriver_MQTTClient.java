package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IMQTTDriver_MQTTClient{
void SwitchOn_from_MQTT(int OnOffMsg_SwitchOn_did_var);
void SwitchOff_from_MQTT(int OnOffMsg_SwitchOff_did_var);
}