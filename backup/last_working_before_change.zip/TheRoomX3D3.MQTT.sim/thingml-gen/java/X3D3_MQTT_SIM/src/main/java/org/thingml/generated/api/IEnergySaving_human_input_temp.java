package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IEnergySaving_human_input_temp{
void set_temperature_via_human_input_temp(double TemperatureMsg_set_temperature_t_var);
}