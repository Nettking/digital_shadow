package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IEnergySaving_get_luminance{
void luminance_via_get_luminance(int LuminanceMsg_luminance_id_var, double LuminanceMsg_luminance_lum_var);
}