package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IHuman_send_cmd_lum_motClient{
void add_lightsensor_from_send_cmd_lum_mot(int LuminanceMsg_add_lightsensor_id_var);
void add_motionsensor_from_send_cmd_lum_mot(int MotionMsg_add_motionsensor_id_var);
}