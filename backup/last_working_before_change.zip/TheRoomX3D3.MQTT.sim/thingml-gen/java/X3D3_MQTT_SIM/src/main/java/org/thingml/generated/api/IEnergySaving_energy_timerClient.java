package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IEnergySaving_energy_timerClient{
void timer_start_from_energy_timer(int TimerMsgs_timer_start_delay_var);
void timer_cancel_from_energy_timer();
}