package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IHuman_send_tempClient{
void set_temperature_from_send_temp(double TemperatureMsg_set_temperature_t_var);
}