package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IEnergySaving_energy_timer{
void timer_timeout_via_energy_timer();
}