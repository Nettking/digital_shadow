package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IHuman_send_day_night_timeClient{
void set_day_start_from_send_day_night_time(int LuminanceMsg_set_day_start_time_var);
void set_night_start_from_send_day_night_time(int LuminanceMsg_set_night_start_time_var);
}