package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IMQTTDriver_provide_tempClient{
void temperature_from_provide_temp(int TemperatureMsg_temperature_id_var, String TemperatureMsg_temperature_txt_var, double TemperatureMsg_temperature_t_var);
}