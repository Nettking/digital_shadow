package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IPIM_guard_humanClient{
void timer_start_from_guard_human(int TimerMsgs_timer_start_delay_var);
void timer_cancel_from_guard_human();
}