package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IMQTTDriver_provide_lum_motionClient{
void luminance_from_provide_lum_motion(int LuminanceMsg_luminance_id_var, double LuminanceMsg_luminance_lum_var);
void motion_from_provide_lum_motion(int MotionMsg_motion_id_var);
void nomotion_from_provide_lum_motion(int MotionMsg_nomotion_id_var);
}