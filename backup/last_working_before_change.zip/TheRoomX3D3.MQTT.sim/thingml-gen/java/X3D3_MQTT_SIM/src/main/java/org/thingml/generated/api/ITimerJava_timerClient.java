package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface ITimerJava_timerClient{
void timer_timeout_from_timer();
}