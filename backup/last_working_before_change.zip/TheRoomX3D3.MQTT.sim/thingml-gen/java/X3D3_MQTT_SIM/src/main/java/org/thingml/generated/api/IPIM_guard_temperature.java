package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IPIM_guard_temperature{
void timer_timeout_via_guard_temperature();
}