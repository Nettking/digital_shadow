package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IPIM_get_sensor{
void temperature_via_get_sensor(int TemperatureMsg_temperature_id_var, String TemperatureMsg_temperature_txt_var, double TemperatureMsg_temperature_t_var);
}