package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IMQTTDriver_require_val{
void add_thermometer_via_require_val(int TemperatureMsg_add_thermometer_id_var, String TemperatureMsg_add_thermometer_txt_var);
void add_lightsensor_via_require_val(int LuminanceMsg_add_lightsensor_id_var);
void add_device_via_require_val(int DeviceGeneral_add_device_did_var);
void SwitchOn_via_require_val(int OnOffMsg_SwitchOn_did_var);
void SwitchOff_via_require_val(int OnOffMsg_SwitchOff_did_var);
}