package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IPIM_request_sensorClient{
void add_thermometer_from_request_sensor(int TemperatureMsg_add_thermometer_id_var, String TemperatureMsg_add_thermometer_txt_var);
}