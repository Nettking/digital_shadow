package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IEnergySaving_get_day_night_time{
void set_day_start_via_get_day_night_time(int LuminanceMsg_set_day_start_time_var);
void set_night_start_via_get_day_night_time(int LuminanceMsg_set_night_start_time_var);
}