package org.thingml.generated.api;

import org.thingml.generated.api.*;

public interface IPIM_guard_temperatureClient{
void timer_start_from_guard_temperature(int TimerMsgs_timer_start_delay_var);
void timer_cancel_from_guard_temperature();
}